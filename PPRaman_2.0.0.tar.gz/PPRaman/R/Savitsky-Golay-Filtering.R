#' Savitsky-Golay filtering
#' SG filtering, adapted from pracma package
#' @param T vector containing spectra, can be used with matrix of spectra using apply with MARGIN = 2
#' @param fl Filter length - size of winder to smooth within
#' @param forder Polynomial order for smoothing window
#' @param dorder Derivative order, 0 for smoothing only, 1,2 = derivatives
#' @return SG filtered spectra
#' @export
#' @import pracma
sav_gol <- function (T, fl, forder = 4, dorder = 0)
{
  stopifnot(is.numeric(T), is.numeric(fl))
  if (fl <= 1 || fl%%2 == 0)
    stop("Argument 'fl' must be an odd integer greater than 1.")
  n <- length(T)
  fc <- (fl - 1)/2
  X <- outer(-fc:fc, 0:forder, FUN = "^")
  Y <- pinv(X)
  T2 <- convolve(T, rev(Y[(dorder + 1), ]), type = "o")
  T2 <- T2[(fc + 1):(length(T2) - fc)]
  Tsg <- (-1)^dorder * T2
  return(Tsg[-c(1:((fl+1)/2), (length(Tsg)-((fl+1)/2)):length(Tsg))])

}
