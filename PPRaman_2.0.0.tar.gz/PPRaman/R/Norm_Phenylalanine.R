#' Normalisation to the Phenylalanine peak
#'
#' Normalising function using min/max method at phenylalanine peak, setting this to 1 and scaling all
#' other data points comparatively.
#' @param spectra Spectra in matrix format for normalising
#' @param bin_size Number of wavenumbers in a bin to shift region to normalise to accordingly
#' @return Normalised spectra
#' @export
norm_p <- function(spectra, bin_size = 1){
  tmp <- spectra
  for (i in 1:nrow(spectra)){
    tmp[i,] <- (spectra[i,] - min(spectra[i,]))/(max(spectra[i,round(300/bin_size):round(400/bin_size)]) - min(spectra[i,]))
  }
  norm_spectra <- tmp
  return(as.data.frame(norm_spectra))
}


