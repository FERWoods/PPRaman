#' Read in spectra, shift and interpolate
#'
#' Reads in spectra with x in first column, y in second, shifts to common reference peak and interpolate onto common wavenumber axis.
#' Recommended use with list of spectra read in from .txt files using lapply.
#' @param spectra Spectra with first column = original x axis, y = intensity.
#' @param abscissa x-axis to interpolate onto.
#' @param reference_peak Peak to shift spectra to, default = 1004 for phenylalanine in blood serum.
#' @param reference_index Index range for finding maximum intensity around reference peak, default = 300:380 for phenylalanine
#' @return Shifted and Interpolated Spectra
#' @export
#'

read_in_shift_general <- function(spectra, abscissa, reference_peak = 1004, reference_index = c(300:380)){

  spectra <- as.data.frame(spectra)
  colnames(spectra) <- c("V1", "V2")
  if(spectra[1,1]>spectra[2,1]){
    spectra <- map_df(spectra, rev)
  }
  x <- spectra$V1
  y <- spectra$V2

  # pull out index of max peak around phenylalanine to shift and store wavenumber/intensity at that point
  max_i <- which.max(y[reference_index])
  shift_i <- max_i + (reference_index[[1]]-1)
  signal_max <- c(shift_i, x[shift_i], y[shift_i])

  # Want to shift to phenylalnine peak but it is coarse so need to fit a polynomial to read off max
  ref_peak <- reference_peak
  SP_index <- c(signal_max[[1]]-2, signal_max[[1]] -1, signal_max[[1]],
                signal_max[[1]] + 1, signal_max[[1]] + 2)
  SP_int <- c(y[SP_index[[1]]], y[SP_index[[2]]],
              y[SP_index[[3]]], y[SP_index[[4]]],
              y[SP_index[[5]]]) # grabs intensity values around the peak

  SP_wn <- c(x[SP_index[[1]]], x[SP_index[[2]]],
             x[SP_index[[3]]], x[SP_index[[4]]],
             x[SP_index[[5]]]) # same again for the x axis

  SP_fit <- polyfit(SP_wn, SP_int, 2) # fits 2nd order poly to phen peak,

  # contruct curve using fit with smaller increments to find shift
  x_ref <- seq(from = SP_wn[[1]], to = SP_wn[[5]], by = 0.1)
  SP_fit_val <- polyval(SP_fit, x_ref)
  # new max index using fit
  max_new_i <- which.max(SP_fit_val)
  # convert to band position in our data
  band_pos <- SP_wn[[1]] + 0.1*(max_new_i-1)
  shift <- ref_peak - band_pos
  # shift the x axis
  x_shift <- x - shift

  # Interpolate onto shifted x-axis
  Shifted_int <- pchip(x, y, x_shift)
  Shifted_wn <- x_shift

  # interpolate onto new common x axis
  interpolated <- interp1(Shifted_wn, Shifted_int, abscissa, "linear")


  return(interpolated)
}
