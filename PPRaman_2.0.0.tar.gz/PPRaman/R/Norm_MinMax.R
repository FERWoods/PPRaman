#' Normalisation using min max
#'
#' Normalising function using min/max method in which the maximum intensity is set to 1 while other
#' data points are scaled in comparatively.
#' @param spectra Spectra in matrix format for normalising
#' @return Normalised spectra
#' @export
norm_minmax <- function(spectra){
  tmp <- spectra
  for (i in 1:nrow(spectra)){
    tmp[i,] <- (spectra[i,] - min(spectra[i,]))/(max(spectra[i,]) - min(spectra[i,]))
  }
  norm_spectra <- tmp
  return(as.data.frame(norm_spectra))
}


