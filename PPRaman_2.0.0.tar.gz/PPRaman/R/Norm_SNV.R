#' Normalising Spectra using SNV
#'
#' Normalises spectra using Standard Normal Variate method method which scales data based on the mean
#' and standard deviation.
#'
#' @param spectra Spectral like data
#' @return Normalised spectra using SNV method
#' @export
#' @references Barnes,  R.  J.;   Dhanoa,  M.  S.;   Lister,  S.  J.Standard   Normal   Variate
#'   Transformation and  De-Trending  of  Near-Infrared  Diffuse Reflectance
#'   Spectra.Applied Spectroscopy 1989,43, 772–777

norm_snv<- function(spectra){
  tmp <- spectra
  for (i in 1:nrow(spectra)){
    mu <- sum(spectra[i,])/length(spectra[i,])
    tmp[i,] <- (spectra[i,] - mu)/sd(spectra[i,])
  }
  norm_spec <- tmp
  return(as.data.frame(norm_spec))
}
