#' Normalising Spectra using Vector Normalising
#'
#' Normalises spectra such that it sums to 1.
#' @param spectra Spectral like data
#' @return Normalised spectra using vector normalising
#' @export
#'

norm_vec<- function(spectra){
  tmp <- spectra
  for (i in 1:nrow(spectra)){
    tmp[i,] <- spectra[i,]/ norm(spectra[i,], type = "2")
  }
  norm_spec <- tmp
  return(as.data.frame(norm_spec))
}

