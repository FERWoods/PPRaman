#' Modified polynomial baseline removal
#'
#' Function computing the modified polynomial baseline correction algorithm
#' @param spectra Matrix containing spectra
#' @param t abcissa for spectra - optional
#' @param degree polynomial degree for baseline fit
#' @param tol tolerance of difference between iterations, default 0.001
#' @param rep Max number of iterations
#' @return Preprocessed spectra
#' @export
#' @references CHAD A. LIEBER and ANITA MAHADEVAN-JANSEN: Automated Method for Subtraction of Fluorescence from Biological Raman Spectra

modpolyfit <- function (spectra, t, degree = 4, tol = 0.001, rep = 100)
{
  dimnames(spectra) <- NULL
  np <- dim(spectra)
  baseline <- matrix(0, np[1], np[2])
  if (missing(t) || (t == FALSE))
    t <- 1:np[2]
  polx <- cbind(1/sqrt(np[2]), stats::poly(t, degree = degree))
  for (i in 1:np[1]) {
    ywork <- yold <- yorig <- spectra[i, ]
    nrep <- 0
    repeat {
      nrep <- nrep + 1
      ypred <- polx %*% crossprod(polx, yold)
      ywork <- pmin(yorig, ypred)
      crit <- sum(abs((ywork - yold)/yold), na.rm = TRUE)
      if (crit < tol || nrep > rep)
        break
      yold <- ywork
    }
    baseline[i, ] <- ypred
  }
  list(baseline = baseline, corrected = spectra - baseline)
}
