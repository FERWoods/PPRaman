#' Normalisation to the Amide I peak
#'
#' Normalising function using min/max method but focused on the Amide I peak which is set 1.
#' @param spectra Spectra in matrix format for normalising
#' @param bin_size Number of wavenumbers in a bin to shift region to normalise to accordingly
#' @return Normalised spectra
#' @export
norm_a <- function(spectra, bin_size = 1){
  tmp <- spectra
  for (i in 1:nrow(spectra)){
    tmp[i,] <- (spectra[i,] - min(spectra[i,]))/(max(spectra[i,round(930/bin_size):round(1000/bin_size)]) - min(spectra[i,]))
  }
  norm_spectra <- tmp
  return(as.data.frame(norm_spectra))
}

