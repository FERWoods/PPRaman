#' Polynomial Baseline Removal # NOT USED IN WRAPPER
#'
#' Wrapper for polynomial baseline removal function using hyperSpec.
#'
#'
#' @param spectra Interpolated spectra
#' @param poly.order Polynomial order
#' @return spectra with polynomial baseline removed
#' @export
#' @references Beleites,  C.  hyperSpec  Introduction. 2015, 1–42
#'

poly_baseline_removal <- function(spectra, poly.order){
  # Uses hyperSpec polynomial baseline removal
  baseline <- spc.fit.poly.below(spectra, poly.order = poly.order)

  # Remove fitted baseline
  spec_corrected <- spectra - baseline

  return(t(spec_corrected$spc))

}
